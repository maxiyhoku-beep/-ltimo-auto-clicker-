package com.ras.autoclicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

/**
 * Puntero flotante.
 * Normal: rojo (en pausa) o verde (funcionando) con el número.
 * Bonus: dorado con una estrella.
 */
class PointerView(ctx: Context, val bonus: Boolean) : View(ctx) {

    var number: Int = 1
        set(value) {
            field = value
            invalidate()
        }

    var running: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        ring.style = Paint.Style.STROKE
        text.textAlign = Paint.Align.CENTER
        text.typeface = Typeface.DEFAULT_BOLD
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val stroke = Ui.dp(context, 3).toFloat()
        val r = minOf(width, height) / 2f - stroke

        val base = when {
            bonus -> Ui.GOLD
            running -> Ui.GREEN
            else -> Ui.RED
        }

        // Relleno semitransparente
        fill.style = Paint.Style.FILL
        fill.color = Color.argb(if (bonus) 235 else 190, Color.red(base), Color.green(base), Color.blue(base))
        canvas.drawCircle(cx, cy, r, fill)

        // Aro exterior negro y aro interior dorado (detalle de la app)
        ring.strokeWidth = stroke
        ring.color = Ui.BLACK
        canvas.drawCircle(cx, cy, r, ring)
        ring.strokeWidth = stroke / 2f
        ring.color = if (bonus) Ui.BLACK else Ui.GOLD
        canvas.drawCircle(cx, cy, r - stroke, ring)

        val label = if (bonus) "★" else number.toString()
        text.color = if (bonus) Ui.BLACK else Color.WHITE
        text.textSize = r * (if (bonus) 1.1f else 0.95f)
        val y = cy - (text.descent() + text.ascent()) / 2f
        canvas.drawText(label, cx, y, text)
    }
}
