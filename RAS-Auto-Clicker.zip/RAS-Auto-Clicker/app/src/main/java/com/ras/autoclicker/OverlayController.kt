package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Panel flotante + punteros. Vive dentro del servicio de accesibilidad
 * (ventanas TYPE_ACCESSIBILITY_OVERLAY, no hace falta otro permiso).
 */
class OverlayController(private val svc: ClickerService) {

    private class Pointer(
        val id: Int,
        val view: PointerView,
        val params: WLP,
        val size: Int,
        var intervalMs: Long
    ) {
        var task: Runnable? = null
    }

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val overlayType = WLP.TYPE_ACCESSIBILITY_OVERLAY
    private val baseFlags = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS or WLP.FLAG_NOT_TOUCH_MODAL
    private val sizePx = Ui.dp(svc, 48)
    private val bonusSizePx = Ui.dp(svc, 58)

    private val pointers = ArrayList<Pointer>()
    private var bonusPointer: Pointer? = null

    private var panelView: LinearLayout? = null
    private var panelParams: WLP? = null
    private var dialogView: View? = null

    private var playBtn: TextView? = null
    private var addBtn: TextView? = null
    private var removeBtn: TextView? = null
    private var eyeBtn: TextView? = null
    private var starBtn: TextView? = null
    private var closeBtn: TextView? = null
    private var saveBtn: TextView? = null

    private var running = false
    private var hidden = false
    private var bonusEnabled = true
    private var bonusGen = 0

    private val releaseHold = Runnable { svc.holdTaps = false }

    // ------------------------------------------------------------ Mostrar / destruir

    fun show(useSaved: Boolean = false) {
        buildPanel()
        val saved = if (useSaved) SavedConfig.load(svc) else null
        if (saved != null && saved.pointers.isNotEmpty()) {
            for (item in saved.pointers) addPointer(item.x, item.y, item.ms)
            bonusEnabled = saved.bonusEnabled
            if (bonusEnabled) {
                addBonusPointer(saved.bonusX, saved.bonusY)
            } else {
                starBtn?.background = Ui.circle(svc, Ui.GRAY)
            }
        } else {
            addPointer()
            addBonusPointer()
        }
    }

    fun destroy() {
        running = false
        bonusGen++
        handler.removeCallbacksAndMessages(null)
        svc.holdTaps = false
        svc.clearQueue()
        closeDialog()
        for (p in pointers) removeSafely(p.view)
        pointers.clear()
        bonusPointer?.let { removeSafely(it.view) }
        bonusPointer = null
        panelView?.let { removeSafely(it) }
        panelView = null
    }

    // ------------------------------------------------------------ Panel

    private fun dp(v: Int): Int = Ui.dp(svc, v)

    /** Botón redondo, grande y de color propio. */
    private fun roundButton(symbol: String, color: Int, textColor: Int): TextView {
        val t = TextView(svc)
        t.text = symbol
        t.textSize = 21f
        t.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        t.setTextColor(textColor)
        t.gravity = Gravity.CENTER
        t.includeFontPadding = false
        t.background = Ui.circle(svc, color)
        val lp = LinearLayout.LayoutParams(dp(46), dp(46))
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        t.layoutParams = lp
        return t
    }

    /**
     * Los botones responden al instante (efecto al tocar) y, mientras se toca el panel,
     * se frenan los toques automáticos para que nada interfiera. Arrastrando desde
     * cualquier botón se mueve el panel.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun bindPanelButton(v: View, onTap: () -> Unit) {
        v.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                val params = panelParams ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                        handler.removeCallbacks(releaseHold)
                        svc.holdTaps = true
                        view.animate().scaleX(0.86f).scaleY(0.86f).setDuration(60).start()
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - touchX
                        val dy = e.rawY - touchY
                        if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > dp(10)) moved = true
                        if (moved) {
                            params.x = startX + dx.toInt()
                            params.y = startY + dy.toInt()
                            panelView?.let { update(it, params) }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                        if (!moved) onTap()
                        handler.postDelayed(releaseHold, 250L)
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                        handler.postDelayed(releaseHold, 250L)
                    }
                }
                return true
            }
        })
    }

    private fun buildPanel() {
        val row = LinearLayout(svc)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.darkBg(svc, 32, 2)
        row.setPadding(dp(5), dp(5), dp(5), dp(5))

        val play = roundButton("▶", Ui.BTN_PLAY, Ui.BLACK)
        val add = roundButton("+", Ui.BTN_ADD, Color.WHITE)
        val remove = roundButton("−", Ui.BTN_REMOVE, Ui.BLACK)
        val eye = roundButton("◉", Ui.BTN_EYE, Color.WHITE)
        val star = roundButton("★", Ui.BTN_STAR, Ui.BLACK)
        val close = roundButton("✕", Ui.BTN_CLOSE, Color.WHITE)
        val save = roundButton("💾", Ui.BTN_SAVE, Color.WHITE)
        save.textSize = 18f

        saveBtn = save
        playBtn = play
        addBtn = add
        removeBtn = remove
        eyeBtn = eye
        starBtn = star
        closeBtn = close

        for (v in listOf(play, add, remove, eye, star, save, close)) row.addView(v)

        val lp = WLP(
            WLP.WRAP_CONTENT, WLP.WRAP_CONTENT, overlayType,
            baseFlags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(110)
        panelParams = lp
        panelView = row

        bindPanelButton(row) { }
        bindPanelButton(play) { setRunning(!running) }
        bindPanelButton(add) { onAdd() }
        bindPanelButton(remove) { onRemove() }
        bindPanelButton(eye) { toggleHidden() }
        bindPanelButton(star) { toggleBonus() }
        bindPanelButton(save) { saveConfig() }
        bindPanelButton(close) { svc.hidePanel() }

        try {
            wm.addView(row, lp)
        } catch (t: Throwable) {
            panelView = null
        }
    }

    /** Con los punteros ocultos el panel queda mínimo: solo iniciar/pausar y mostrar. */
    private fun applyPanelMode() {
        val vis = if (hidden) View.GONE else View.VISIBLE
        addBtn?.visibility = vis
        removeBtn?.visibility = vis
        starBtn?.visibility = vis
        saveBtn?.visibility = vis
        closeBtn?.visibility = vis
        val params = panelParams
        val view = panelView
        if (params != null && view != null) update(view, params)
    }

    private fun stylePlay() {
        val btn = playBtn ?: return
        if (running) {
            btn.text = "❚❚"
            btn.textSize = 16f
            btn.setTextColor(Color.WHITE)
            btn.background = Ui.circle(svc, Ui.BTN_PAUSE)
        } else {
            btn.text = "▶"
            btn.textSize = 21f
            btn.setTextColor(Ui.BLACK)
            btn.background = Ui.circle(svc, Ui.BTN_PLAY)
        }
    }

    // ------------------------------------------------------------ Punteros

    private fun makeParams(x: Int, y: Int, size: Int): WLP {
        val lp = WLP(size, size, overlayType, baseFlags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y
        return lp
    }

    private fun addPointer(savedX: Int? = null, savedY: Int? = null, savedMs: Long = 1000L) {
        val dm = svc.resources.displayMetrics
        val n = pointers.size
        val x = savedX ?: (dm.widthPixels / 2 - sizePx / 2 - dp(70) + (n % 5) * dp(16))
        val y = savedY ?: (dm.heightPixels / 3 + (n % 6) * (sizePx + dp(10)))

        val view = PointerView(svc, false)
        view.number = n + 1
        val p = Pointer(n + 1, view, makeParams(x, y, sizePx), sizePx, savedMs)
        pointers.add(p)
        attachTouch(p)
        applyState(p)
        try {
            wm.addView(view, p.params)
        } catch (t: Throwable) {
            pointers.remove(p)
            return
        }
        if (running) schedule(p)
    }

    private fun addBonusPointer(savedX: Int? = null, savedY: Int? = null) {
        if (bonusPointer != null) return
        val dm = svc.resources.displayMetrics
        val x = savedX ?: (dm.widthPixels / 2 - bonusSizePx / 2)
        val y = savedY ?: ((dm.heightPixels * 0.78f).toInt() - bonusSizePx / 2)

        val view = PointerView(svc, true)
        val p = Pointer(0, view, makeParams(x, y, bonusSizePx), bonusSizePx, 0L)
        bonusPointer = p
        attachTouch(p)
        applyState(p)
        try {
            wm.addView(view, p.params)
        } catch (t: Throwable) {
            bonusPointer = null
        }
    }

    /** Color, visibilidad y si deja pasar los toques (los punteros solo se mueven en pausa). */
    private fun applyState(p: Pointer) {
        p.view.running = running
        p.view.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
        val touchable = !running && !hidden
        p.params.flags = if (touchable) baseFlags else baseFlags or WLP.FLAG_NOT_TOUCHABLE
        if (p.view.isAttachedToWindow) update(p.view, p.params)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(p: Pointer) {
        p.view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) {
                    startX = p.params.x
                    startY = p.params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                } else if (e.action == MotionEvent.ACTION_MOVE) {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > dp(6)) moved = true
                    if (moved) {
                        p.params.x = startX + dx.toInt()
                        p.params.y = startY + dy.toInt()
                        update(v, p.params)
                    }
                } else if (e.action == MotionEvent.ACTION_UP) {
                    if (!moved && !p.view.bonus) showSpeedDialog(p)
                }
                return true
            }
        })
    }

    private fun centerOf(p: Pointer): FloatArray {
        val loc = IntArray(2)
        p.view.getLocationOnScreen(loc)
        return if (p.view.width > 0) {
            floatArrayOf(loc[0] + p.view.width / 2f, loc[1] + p.view.height / 2f)
        } else {
            floatArrayOf(p.params.x + p.size / 2f, p.params.y + p.size / 2f)
        }
    }

    // ------------------------------------------------------------ Acciones del panel

    private fun onAdd() {
        if (pointers.size >= 20) {
            toast(L.t("max_pointers"))
            return
        }
        addPointer()
        toast(L.t("pointer_added"))
    }

    private fun onRemove() {
        if (pointers.isEmpty()) {
            toast(L.t("no_pointers"))
            return
        }
        val p = pointers.removeAt(pointers.size - 1)
        p.task?.let { handler.removeCallbacks(it) }
        removeSafely(p.view)
        toast(L.t("pointer_removed"))
    }

    /** Guarda posición y velocidad de los punteros y el puntero de bonus. */
    private fun saveConfig() {
        val items = pointers.map { SavedConfig.Item(it.params.x, it.params.y, it.intervalMs) }
        val dm = svc.resources.displayMetrics
        val bp = bonusPointer
        val bonusX = bp?.params?.x ?: (dm.widthPixels / 2 - bonusSizePx / 2)
        val bonusY = bp?.params?.y ?: ((dm.heightPixels * 0.78f).toInt() - bonusSizePx / 2)
        SavedConfig.save(svc, SavedConfig.Data(items, bonusEnabled, bonusX, bonusY))
        toast(L.t("config_saved"))
    }

    private fun toggleHidden() {
        hidden = !hidden
        for (p in pointers) applyState(p)
        bonusPointer?.let { applyState(it) }
        eyeBtn?.text = if (hidden) "○" else "◉"
        applyPanelMode()
        toast(L.t(if (hidden) "pointers_hidden" else "pointers_shown"))
    }

    private fun toggleBonus() {
        bonusEnabled = !bonusEnabled
        starBtn?.background = Ui.circle(svc, if (bonusEnabled) Ui.BTN_STAR else Ui.GRAY)
        if (bonusEnabled) {
            addBonusPointer()
            if (running) startBonusLoop()
        } else {
            bonusGen++
            bonusPointer?.let { removeSafely(it.view) }
            bonusPointer = null
        }
        toast(L.t(if (bonusEnabled) "bonus_on" else "bonus_off"))
    }

    // ------------------------------------------------------------ Funcionamiento

    private fun setRunning(on: Boolean) {
        if (on == running) return
        running = on
        stylePlay()
        for (p in pointers) applyState(p)
        bonusPointer?.let { applyState(it) }

        if (on) {
            for (p in pointers) schedule(p)
            if (bonusEnabled && bonusPointer != null) startBonusLoop()
            toast(L.t("running_on"))
        } else {
            // Pausa total e inmediata: cancela temporizadores, detección y toques pendientes
            handler.removeCallbacksAndMessages(null)
            bonusGen++
            svc.clearQueue()
            toast(L.t("running_off"))
        }
    }

    private fun schedule(p: Pointer) {
        val task = object : Runnable {
            override fun run() {
                if (!running || !pointers.contains(p)) return
                val c = centerOf(p)
                svc.enqueueTap(c[0], c[1])
                handler.postDelayed(this, p.intervalMs)
            }
        }
        p.task = task
        handler.postDelayed(task, 300L)
    }

    private fun startBonusLoop() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            toast(L.t("bonus_unsupported"))
            return
        }
        bonusGen++
        val gen = bonusGen
        handler.postDelayed({ bonusStep(gen) }, 600L)
    }

    private fun bonusStep(gen: Int) {
        if (gen != bonusGen || !running || !bonusEnabled) return
        val bp = bonusPointer
        if (bp == null) {
            handler.postDelayed({ bonusStep(gen) }, 800L)
            return
        }
        val c = centerOf(bp)
        svc.detectBonus(c[0].toInt(), c[1].toInt()) { result ->
            if (gen == bonusGen && running) {
                var delay = 800L
                if (result != null) {
                    svc.enqueueTap(result[0].toFloat(), result[1].toFloat())
                    delay = 2200L // espera a que el cartel desaparezca
                }
                handler.postDelayed({ bonusStep(gen) }, delay)
            }
        }
    }

    // ------------------------------------------------------------ Ventana de velocidad (compacta)

    private fun formatMs(ms: Long): String =
        if (ms >= 1000L && ms % 1000L == 0L) "${ms / 1000L} s" else "$ms ms"

    private fun showSpeedDialog(p: Pointer) {
        closeDialog()
        val ctx: Context = svc
        var useSeconds = p.intervalMs >= 1000L && p.intervalMs % 1000L == 0L
        val initial = if (useSeconds) (p.intervalMs / 1000L).toString() else p.intervalMs.toString()

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.background = Ui.darkBg(ctx, 14, 2)
        box.setPadding(dp(12), dp(10), dp(12), dp(12))

        fun rowParams(top: Int): LinearLayout.LayoutParams {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(top)
            return lp
        }

        box.addView(Ui.label(ctx, "${L.t("pointer")} ${p.id} · ${L.t("speed_short")}", 15f, Ui.GOLD, true))

        // Valor + unidad en una sola fila
        val valueRow = LinearLayout(ctx)
        valueRow.orientation = LinearLayout.HORIZONTAL
        valueRow.gravity = Gravity.CENTER_VERTICAL

        val input = EditText(ctx)
        input.setText(initial)
        input.setSelectAllOnFocus(true)
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        input.setTextColor(Color.WHITE)
        input.textSize = 20f
        input.gravity = Gravity.CENTER
        input.setSingleLine(true)
        input.background = Ui.darkBg(ctx, 10, 1)
        input.setPadding(dp(6), 0, dp(6), 0)
        valueRow.addView(input, LinearLayout.LayoutParams(0, dp(44), 1f))

        val msBtn = Ui.smallButton(ctx, "ms", false)
        val sBtn = Ui.smallButton(ctx, "s", false)
        val msLp = LinearLayout.LayoutParams(dp(50), dp(44))
        msLp.leftMargin = dp(6)
        val sLp = LinearLayout.LayoutParams(dp(42), dp(44))
        sLp.leftMargin = dp(4)
        valueRow.addView(msBtn, msLp)
        valueRow.addView(sBtn, sLp)
        box.addView(valueRow, rowParams(8))

        fun styleUnits() {
            msBtn.background = if (!useSeconds) Ui.goldBg(ctx, 10) else Ui.darkBg(ctx, 10, 2)
            msBtn.setTextColor(if (!useSeconds) Ui.BLACK else Ui.GOLD)
            sBtn.background = if (useSeconds) Ui.goldBg(ctx, 10) else Ui.darkBg(ctx, 10, 2)
            sBtn.setTextColor(if (useSeconds) Ui.BLACK else Ui.GOLD)
        }
        styleUnits()
        msBtn.setOnClickListener {
            useSeconds = false
            styleUnits()
        }
        sBtn.setOnClickListener {
            useSeconds = true
            styleUnits()
        }

        // Cancelar / Guardar
        val buttons = LinearLayout(ctx)
        buttons.orientation = LinearLayout.HORIZONTAL
        val cancel = Ui.smallButton(ctx, L.t("cancel"), false)
        val save = Ui.smallButton(ctx, L.t("save"), true)
        val b1 = LinearLayout.LayoutParams(0, dp(42), 1f)
        b1.rightMargin = dp(4)
        val b2 = LinearLayout.LayoutParams(0, dp(42), 1f)
        b2.leftMargin = dp(4)
        buttons.addView(cancel, b1)
        buttons.addView(save, b2)
        box.addView(buttons, rowParams(8))

        cancel.setOnClickListener { closeDialog() }
        save.setOnClickListener {
            val value = input.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (value == null || value <= 0.0) {
                toast(L.t("invalid_value"))
            } else {
                val raw = if (useSeconds) (value * 1000.0).toLong() else value.toLong()
                val ms = raw.coerceIn(30L, 3_600_000L)
                p.intervalMs = ms
                toast("${L.t("speed_set")}: ${formatMs(ms)}")
                closeDialog()
            }
        }

        val dm = ctx.resources.displayMetrics
        val width = minOf(dm.widthPixels - dp(40), dp(260))
        val lp = WLP(width, WLP.WRAP_CONTENT, overlayType, 0, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(70)
        lp.softInputMode = WLP.SOFT_INPUT_ADJUST_PAN

        try {
            wm.addView(box, lp)
            dialogView = box
            input.requestFocus()
        } catch (t: Throwable) {
            dialogView = null
        }
    }

    private fun closeDialog() {
        dialogView?.let { removeSafely(it) }
        dialogView = null
    }

    // ------------------------------------------------------------ Utilidades

    private fun update(v: View, lp: WLP) {
        try {
            wm.updateViewLayout(v, lp)
        } catch (t: Throwable) {
            // la vista ya no está
        }
    }

    private fun removeSafely(v: View) {
        try {
            wm.removeView(v)
        } catch (t: Throwable) {
            // ya estaba removida
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(svc, msg, Toast.LENGTH_SHORT).show()
    }
}
