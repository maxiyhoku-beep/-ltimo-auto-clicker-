package com.ras.autoclicker

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Panel flotante + punteros. Vive dentro del servicio de accesibilidad
 * (ventanas TYPE_ACCESSIBILITY_OVERLAY, no hace falta otro permiso).
 */
class OverlayController(private val svc: ClickerService) {

    private class Pointer(
        val id: Int,
        val view: PointerView,
        val params: WLP,
        var intervalMs: Long
    ) {
        var task: Runnable? = null
    }

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val overlayType = WLP.TYPE_ACCESSIBILITY_OVERLAY
    private val baseFlags = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS or WLP.FLAG_NOT_TOUCH_MODAL
    private val sizePx = Ui.dp(svc, 46)

    private val pointers = ArrayList<Pointer>()
    private var bonusPointer: Pointer? = null

    private var panelView: LinearLayout? = null
    private var panelParams: WLP? = null
    private var dialogView: View? = null

    private var playBtn: TextView? = null
    private var eyeBtn: TextView? = null
    private var starBtn: TextView? = null

    private var running = false
    private var hidden = false
    private var bonusEnabled = true
    private var bonusGen = 0

    // ------------------------------------------------------------ Mostrar / destruir

    fun show() {
        buildPanel()
        addPointer()
        addBonusPointer()
    }

    fun destroy() {
        running = false
        bonusGen++
        handler.removeCallbacksAndMessages(null)
        closeDialog()
        for (p in pointers) removeSafely(p.view)
        pointers.clear()
        bonusPointer?.let { removeSafely(it.view) }
        bonusPointer = null
        panelView?.let { removeSafely(it) }
        panelView = null
    }

    // ------------------------------------------------------------ Panel

    private fun dp(v: Int): Int = Ui.dp(svc, v)

    private fun panelButton(text: String): TextView {
        val t = Ui.label(svc, text, 20f, Ui.GOLD, true)
        t.gravity = Gravity.CENTER
        t.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        return t
    }

    private fun buildPanel() {
        val row = LinearLayout(svc)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.darkBg(svc, 26, 2)
        row.setPadding(dp(6), dp(4), dp(6), dp(4))

        val handle = panelButton("☰")
        val play = panelButton("▶")
        val add = panelButton("+")
        val remove = panelButton("−")
        val eye = panelButton("◉")
        val star = panelButton("★")
        val close = panelButton("✕")

        play.setTextColor(Ui.BLACK)
        play.background = Ui.goldBg(svc, 21)
        close.setTextColor(Ui.RED)

        playBtn = play
        eyeBtn = eye
        starBtn = star

        for (v in listOf(handle, play, add, remove, eye, star, close)) row.addView(v)

        val lp = WLP(
            WLP.WRAP_CONTENT, WLP.WRAP_CONTENT, overlayType,
            baseFlags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(110)
        panelParams = lp
        panelView = row

        // Arrastrar el panel desde el asa ☰
        handle.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val params = panelParams ?: return false
                if (e.action == MotionEvent.ACTION_DOWN) {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                } else if (e.action == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    panelView?.let { update(it, params) }
                }
                return true
            }
        })

        play.setOnClickListener { setRunning(!running) }
        add.setOnClickListener { onAdd() }
        remove.setOnClickListener { onRemove() }
        eye.setOnClickListener { toggleHidden() }
        star.setOnClickListener { toggleBonus() }
        close.setOnClickListener { svc.hidePanel() }

        try {
            wm.addView(row, lp)
        } catch (t: Throwable) {
            panelView = null
        }
    }

    // ------------------------------------------------------------ Punteros

    private fun makeParams(x: Int, y: Int): WLP {
        val lp = WLP(sizePx, sizePx, overlayType, baseFlags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y
        return lp
    }

    private fun addPointer() {
        val dm = svc.resources.displayMetrics
        val n = pointers.size
        val x = dm.widthPixels / 2 - sizePx / 2 - dp(70) + (n % 5) * dp(16)
        val y = dm.heightPixels / 3 + (n % 6) * (sizePx + dp(10))

        val view = PointerView(svc, false)
        view.number = n + 1
        val p = Pointer(n + 1, view, makeParams(x, y), 1000L)
        pointers.add(p)
        attachTouch(p)
        applyState(p)
        try {
            wm.addView(view, p.params)
        } catch (t: Throwable) {
            pointers.remove(p)
            return
        }
        if (running) schedule(p)
    }

    private fun addBonusPointer() {
        if (bonusPointer != null) return
        val dm = svc.resources.displayMetrics
        val x = dm.widthPixels / 2 - sizePx / 2
        val y = (dm.heightPixels * 0.80f).toInt() - sizePx / 2

        val view = PointerView(svc, true)
        val p = Pointer(0, view, makeParams(x, y), 0L)
        bonusPointer = p
        attachTouch(p)
        applyState(p)
        try {
            wm.addView(view, p.params)
        } catch (t: Throwable) {
            bonusPointer = null
        }
    }

    /** Color, visibilidad y si deja pasar los toques (los punteros solo se mueven en pausa). */
    private fun applyState(p: Pointer) {
        p.view.running = running
        p.view.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
        val touchable = !running && !hidden
        p.params.flags = if (touchable) baseFlags else baseFlags or WLP.FLAG_NOT_TOUCHABLE
        if (p.view.isAttachedToWindow) update(p.view, p.params)
    }

    private fun attachTouch(p: Pointer) {
        p.view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) {
                    startX = p.params.x
                    startY = p.params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                } else if (e.action == MotionEvent.ACTION_MOVE) {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > dp(8)) moved = true
                    if (moved) {
                        p.params.x = startX + dx.toInt()
                        p.params.y = startY + dy.toInt()
                        update(v, p.params)
                    }
                } else if (e.action == MotionEvent.ACTION_UP) {
                    if (!moved && !p.view.bonus) showSpeedDialog(p)
                }
                return true
            }
        })
    }

    private fun centerOf(p: Pointer): FloatArray {
        val loc = IntArray(2)
        p.view.getLocationOnScreen(loc)
        return if (p.view.width > 0) {
            floatArrayOf(loc[0] + p.view.width / 2f, loc[1] + p.view.height / 2f)
        } else {
            floatArrayOf(p.params.x + sizePx / 2f, p.params.y + sizePx / 2f)
        }
    }

    // ------------------------------------------------------------ Acciones del panel

    private fun onAdd() {
        if (pointers.size >= 20) {
            toast(L.t("max_pointers"))
            return
        }
        addPointer()
        toast(L.t("pointer_added"))
    }

    private fun onRemove() {
        if (pointers.isEmpty()) {
            toast(L.t("no_pointers"))
            return
        }
        val p = pointers.removeAt(pointers.size - 1)
        p.task?.let { handler.removeCallbacks(it) }
        removeSafely(p.view)
        toast(L.t("pointer_removed"))
    }

    private fun toggleHidden() {
        hidden = !hidden
        for (p in pointers) applyState(p)
        bonusPointer?.let { applyState(it) }
        eyeBtn?.text = if (hidden) "○" else "◉"
        eyeBtn?.setTextColor(if (hidden) Ui.GRAY else Ui.GOLD)
        toast(L.t(if (hidden) "pointers_hidden" else "pointers_shown"))
    }

    private fun toggleBonus() {
        bonusEnabled = !bonusEnabled
        starBtn?.setTextColor(if (bonusEnabled) Ui.GOLD else Ui.GRAY)
        if (bonusEnabled) {
            addBonusPointer()
            if (running) startBonusLoop()
        } else {
            bonusGen++
            bonusPointer?.let { removeSafely(it.view) }
            bonusPointer = null
        }
        toast(L.t(if (bonusEnabled) "bonus_on" else "bonus_off"))
    }

    // ------------------------------------------------------------ Funcionamiento

    private fun setRunning(on: Boolean) {
        if (on == running) return
        running = on
        playBtn?.text = if (on) "■" else "▶"
        for (p in pointers) applyState(p)
        bonusPointer?.let { applyState(it) }

        if (on) {
            for (p in pointers) schedule(p)
            if (bonusEnabled && bonusPointer != null) startBonusLoop()
            toast(L.t("running_on"))
        } else {
            handler.removeCallbacksAndMessages(null)
            bonusGen++
            toast(L.t("running_off"))
        }
    }

    private fun schedule(p: Pointer) {
        val task = object : Runnable {
            override fun run() {
                if (!running || !pointers.contains(p)) return
                val c = centerOf(p)
                svc.enqueueTap(c[0], c[1])
                handler.postDelayed(this, p.intervalMs)
            }
        }
        p.task = task
        handler.postDelayed(task, 300L)
    }

    private fun startBonusLoop() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            toast(L.t("bonus_unsupported"))
            return
        }
        bonusGen++
        val gen = bonusGen
        handler.postDelayed({ bonusStep(gen) }, 600L)
    }

    private fun bonusStep(gen: Int) {
        if (gen != bonusGen || !running || !bonusEnabled) return
        val bp = bonusPointer
        if (bp == null) {
            handler.postDelayed({ bonusStep(gen) }, 800L)
            return
        }
        val c = centerOf(bp)
        svc.detectBonus(c[0].toInt(), c[1].toInt()) { result ->
            if (gen == bonusGen && running) {
                var delay = 800L
                if (result != null) {
                    svc.enqueueTap(result[0].toFloat(), result[1].toFloat())
                    delay = 2200L // espera a que el cartel desaparezca
                }
                handler.postDelayed({ bonusStep(gen) }, delay)
            }
        }
    }

    // ------------------------------------------------------------ Ventana de velocidad

    private fun formatMs(ms: Long): String =
        if (ms >= 1000L && ms % 1000L == 0L) "${ms / 1000L} s" else "$ms ms"

    private fun showSpeedDialog(p: Pointer) {
        closeDialog()
        val ctx: Context = svc
        var useSeconds = p.intervalMs >= 1000L && p.intervalMs % 1000L == 0L
        val initial = if (useSeconds) (p.intervalMs / 1000L).toString() else p.intervalMs.toString()

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.background = Ui.darkBg(ctx, 18, 2)
        box.setPadding(dp(18), dp(16), dp(18), dp(16))

        fun rowParams(top: Int): LinearLayout.LayoutParams {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(top)
            return lp
        }

        box.addView(Ui.label(ctx, "${L.t("speed_title")} · ${L.t("pointer")} ${p.id}", 18f, Ui.GOLD, true))
        box.addView(Ui.label(ctx, L.t("speed_hint"), 13f, Ui.GRAY, false))

        val input = EditText(ctx)
        input.setText(initial)
        input.setSelectAllOnFocus(true)
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Ui.GRAY)
        input.textSize = 24f
        input.gravity = Gravity.CENTER
        input.setSingleLine(true)
        input.background = Ui.darkBg(ctx, 10, 1)
        input.setPadding(dp(12), dp(10), dp(12), dp(10))
        box.addView(input, rowParams(12))

        // Unidad: ms / s
        val unitRow = LinearLayout(ctx)
        unitRow.orientation = LinearLayout.HORIZONTAL
        val msBtn = Ui.button(ctx, "ms", false)
        val sBtn = Ui.button(ctx, "s", false)
        val half = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        half.rightMargin = dp(4)
        val half2 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        half2.leftMargin = dp(4)
        unitRow.addView(msBtn, half)
        unitRow.addView(sBtn, half2)
        box.addView(unitRow, rowParams(10))

        fun styleUnits() {
            msBtn.background = if (!useSeconds) Ui.goldBg(ctx, 14) else Ui.darkBg(ctx, 14, 2)
            msBtn.setTextColor(if (!useSeconds) Ui.BLACK else Ui.GOLD)
            sBtn.background = if (useSeconds) Ui.goldBg(ctx, 14) else Ui.darkBg(ctx, 14, 2)
            sBtn.setTextColor(if (useSeconds) Ui.BLACK else Ui.GOLD)
        }
        styleUnits()
        msBtn.setOnClickListener { useSeconds = false; styleUnits() }
        sBtn.setOnClickListener { useSeconds = true; styleUnits() }

        // Atajos rápidos
        val presetRow = LinearLayout(ctx)
        presetRow.orientation = LinearLayout.HORIZONTAL
        val presets = listOf(
            Triple("50 ms", "50", false),
            Triple("100 ms", "100", false),
            Triple("500 ms", "500", false),
            Triple("1 s", "1", true)
        )
        for (preset in presets) {
            val chip = Ui.label(ctx, preset.first, 13f, Ui.GOLD, true)
            chip.gravity = Gravity.CENTER
            chip.background = Ui.darkBg(ctx, 10, 1)
            chip.setPadding(dp(4), dp(8), dp(4), dp(8))
            val clp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            clp.leftMargin = dp(2)
            clp.rightMargin = dp(2)
            chip.setOnClickListener {
                input.setText(preset.second)
                input.setSelection(input.text.length)
                useSeconds = preset.third
                styleUnits()
            }
            presetRow.addView(chip, clp)
        }
        box.addView(presetRow, rowParams(10))

        // Cancelar / Guardar
        val buttons = LinearLayout(ctx)
        buttons.orientation = LinearLayout.HORIZONTAL
        val cancel = Ui.button(ctx, L.t("cancel"), false)
        val save = Ui.button(ctx, L.t("save"), true)
        val b1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        b1.rightMargin = dp(4)
        val b2 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        b2.leftMargin = dp(4)
        buttons.addView(cancel, b1)
        buttons.addView(save, b2)
        box.addView(buttons, rowParams(14))

        cancel.setOnClickListener { closeDialog() }
        save.setOnClickListener {
            val value = input.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (value == null || value <= 0.0) {
                toast(L.t("invalid_value"))
            } else {
                val raw = if (useSeconds) (value * 1000.0).toLong() else value.toLong()
                val ms = raw.coerceIn(30L, 3_600_000L)
                p.intervalMs = ms
                toast("${L.t("speed_set")}: ${formatMs(ms)}")
                closeDialog()
            }
        }

        val dm = ctx.resources.displayMetrics
        val width = minOf(dm.widthPixels - dp(32), dp(340))
        val lp = WLP(width, WLP.WRAP_CONTENT, overlayType, WLP.FLAG_DIM_BEHIND, PixelFormat.TRANSLUCENT)
        lp.dimAmount = 0.6f
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(90)
        lp.softInputMode = WLP.SOFT_INPUT_ADJUST_PAN

        try {
            wm.addView(box, lp)
            dialogView = box
            input.requestFocus()
        } catch (t: Throwable) {
            dialogView = null
        }
    }

    private fun closeDialog() {
        dialogView?.let { removeSafely(it) }
        dialogView = null
    }

    // ------------------------------------------------------------ Utilidades

    private fun update(v: View, lp: WLP) {
        try {
            wm.updateViewLayout(v, lp)
        } catch (t: Throwable) {
            // la vista ya no está
        }
    }

    private fun removeSafely(v: View) {
        try {
            wm.removeView(v)
        } catch (t: Throwable) {
            // ya estaba removida
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(svc, msg, Toast.LENGTH_SHORT).show()
    }
}
