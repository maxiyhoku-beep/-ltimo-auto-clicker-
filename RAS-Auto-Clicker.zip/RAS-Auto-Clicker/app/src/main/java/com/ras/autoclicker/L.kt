package com.ras.autoclicker

import android.content.Context
import java.util.Locale

/** Traducciones de la app (español / inglés). */
object L {
    var lang: String = "es"
        private set

    private const val PREFS = "ras_prefs"

    fun load(ctx: Context) {
        val saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", null)
        lang = saved ?: if (Locale.getDefault().language == "es") "es" else "en"
    }

    fun set(ctx: Context, value: String) {
        lang = value
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lang", value).apply()
    }

    fun t(key: String): String = (if (lang == "en") EN else ES)[key] ?: key

    private val ES = mapOf(
        "status_on" to "Servicio de accesibilidad: ACTIVO",
        "status_off" to "Servicio de accesibilidad: DESACTIVADO",
        "enable_panel" to "ACTIVAR PANEL",
        "disable_panel" to "DESACTIVAR PANEL",
        "channels" to "CANALES",
        "back" to "VOLVER",
        "language" to "Idioma",
        "hint_main" to "Activá el panel, abrí el juego y colocá los punteros donde quieras que toque. Con el panel flotante podés iniciar, pausar, agregar, quitar y ocultar punteros.",
        "acc_title" to "Falta un permiso",
        "acc_msg" to "Para que la app pueda tocar la pantalla necesitás activar el servicio de accesibilidad:\n\n1. Tocá «Abrir ajustes».\n2. Entrá en «Apps instaladas» o «Servicios descargados».\n3. Elegí RAS//Auto-Clicker y activalo.\n\nSi Android lo bloquea («ajuste restringido»), andá a Info de la app → menú ⋮ → «Permitir ajustes restringidos» y probá de nuevo.",
        "open_settings" to "Abrir ajustes",
        "cancel" to "Cancelar",
        "save" to "Guardar",
        "pointer" to "Puntero",
        "speed_title" to "Velocidad del puntero",
        "speed_hint" to "Cada cuánto toca este puntero",
        "invalid_value" to "Valor no válido",
        "speed_set" to "Velocidad guardada",
        "panel_on" to "Panel activado. Abrí el juego.",
        "panel_off" to "Panel desactivado",
        "pointer_added" to "Puntero agregado",
        "pointer_removed" to "Puntero quitado",
        "max_pointers" to "Máximo de punteros alcanzado",
        "no_pointers" to "No hay punteros para quitar",
        "pointers_hidden" to "Punteros ocultos (siguen funcionando)",
        "pointers_shown" to "Punteros visibles",
        "bonus_on" to "Puntero de bonus activado",
        "bonus_off" to "Puntero de bonus desactivado",
        "bonus_unsupported" to "La detección del bonus necesita Android 11 o superior",
        "running_on" to "Auto clicker iniciado",
        "running_off" to "Auto clicker en pausa",
        "pause_to_edit" to "Pausá para mover o editar los punteros",
        "speed_short" to "Velocidad",
        "guide_title" to "¿Qué hace cada botón?",
        "guide_play" to "Inicia o pausa todos los clics. Verde = iniciar, naranja = pausar (corta al instante).",
        "guide_add" to "Agrega un puntero nuevo (rojo/verde). Arrastralo en pausa adonde quieras que toque.",
        "guide_remove" to "Quita el último puntero agregado.",
        "guide_eye" to "Oculta los punteros (siguen funcionando) y achica el panel. Tocalo de nuevo para mostrarlos.",
        "guide_star" to "Activa o desactiva el puntero dorado del bonus. Ponelo entre OK y GO TO CARDS.",
        "guide_close" to "Cierra el panel.",
        "guide_tip" to "Tip: en pausa podés arrastrar los punteros y el panel. Tocá un puntero para cambiar su velocidad (ms o s).",
        "channel_prefix" to "CANAL",
        "channels_title" to "Canales",
        "open_failed" to "No se pudo abrir el enlace"
    )

    private val EN = mapOf(
        "status_on" to "Accessibility service: ACTIVE",
        "status_off" to "Accessibility service: OFF",
        "enable_panel" to "ENABLE PANEL",
        "disable_panel" to "DISABLE PANEL",
        "channels" to "CHANNELS",
        "back" to "BACK",
        "language" to "Language",
        "hint_main" to "Enable the panel, open the game and place the pointers where you want it to tap. With the floating panel you can start, pause, add, remove and hide pointers.",
        "acc_title" to "Permission needed",
        "acc_msg" to "For the app to tap the screen you need to turn on the accessibility service:\n\n1. Tap “Open settings”.\n2. Go to “Installed apps” or “Downloaded services”.\n3. Choose RAS//Auto-Clicker and turn it on.\n\nIf Android blocks it (“restricted setting”), go to App info → ⋮ menu → “Allow restricted settings” and try again.",
        "open_settings" to "Open settings",
        "cancel" to "Cancel",
        "save" to "Save",
        "pointer" to "Pointer",
        "speed_title" to "Pointer speed",
        "speed_hint" to "How often this pointer taps",
        "invalid_value" to "Invalid value",
        "speed_set" to "Speed saved",
        "panel_on" to "Panel enabled. Open the game.",
        "panel_off" to "Panel disabled",
        "pointer_added" to "Pointer added",
        "pointer_removed" to "Pointer removed",
        "max_pointers" to "Maximum number of pointers reached",
        "no_pointers" to "No pointers to remove",
        "pointers_hidden" to "Pointers hidden (still working)",
        "pointers_shown" to "Pointers visible",
        "bonus_on" to "Bonus pointer enabled",
        "bonus_off" to "Bonus pointer disabled",
        "bonus_unsupported" to "Bonus detection needs Android 11 or higher",
        "running_on" to "Auto clicker started",
        "running_off" to "Auto clicker paused",
        "pause_to_edit" to "Pause to move or edit the pointers",
        "speed_short" to "Speed",
        "guide_title" to "What does each button do?",
        "guide_play" to "Starts or pauses all clicks. Green = start, orange = pause (stops instantly).",
        "guide_add" to "Adds a new pointer (red/green). Drag it while paused to where you want it to tap.",
        "guide_remove" to "Removes the last pointer added.",
        "guide_eye" to "Hides the pointers (they keep working) and shrinks the panel. Tap again to show them.",
        "guide_star" to "Turns the golden bonus pointer on or off. Place it between OK and GO TO CARDS.",
        "guide_close" to "Closes the panel.",
        "guide_tip" to "Tip: while paused you can drag the pointers and the panel. Tap a pointer to change its speed (ms or s).",
        "channel_prefix" to "CHANNEL",
        "channels_title" to "Channels",
        "open_failed" to "Could not open the link"
    )
}
