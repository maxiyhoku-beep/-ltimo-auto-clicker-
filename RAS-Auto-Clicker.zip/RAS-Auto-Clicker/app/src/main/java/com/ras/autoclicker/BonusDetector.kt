package com.ras.autoclicker

import android.graphics.Bitmap

/**
 * Detecta el cartel "BONUS" del juego a partir de una captura de pantalla.
 *
 * El puntero dorado se coloca entre los dos botones del cartel (OK y GO TO CARDS).
 * Se buscan, a la altura del puntero, dos bloques claros (los botones) de ancho parecido
 * con el puntero entre ambos. Luego se decide cuál es "OK" contando los píxeles oscuros
 * (texto): "GO TO CARDS" tiene mucho más texto que "OK", así que el botón con menos texto
 * es OK, ya sea que esté a la izquierda o a la derecha.
 *
 * Devuelve [x, y] donde tocar, o null si no hay cartel (o si no está seguro).
 */
object BonusDetector {

    private fun isBright(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        return minOf(r, minOf(g, b)) >= 160 && (r + g + b) / 3 >= 190
    }

    private fun isDark(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        return (r * 299 + g * 587 + b * 114) / 1000 < 120
    }

    /**
     * Como cada pantalla tiene distinto tamaño/dpi, el puntero puede quedar un poco más
     * arriba o abajo que los botones. Por eso se prueba a la altura del puntero y, si no
     * hay resultado, un poco más arriba y más abajo (hasta ~6% del alto de pantalla).
     */
    fun find(bmp: Bitmap, px: Int, py: Int): IntArray? {
        val w = bmp.width
        val h = bmp.height
        if (px < 0 || px >= w || py < 0 || py >= h) return null

        val step = maxOf(4, (h * 0.012f).toInt())
        val order = intArrayOf(0, -1, 1, -2, 2, -3, 3, -4, 4, -5, 5)
        for (k in order) {
            val y = py + k * step
            if (y < 0 || y >= h) continue
            val r = findAt(bmp, px, y)
            if (r != null) return r
        }
        return null
    }

    private fun findAt(bmp: Bitmap, px: Int, py: Int): IntArray? {
        val w = bmp.width
        val h = bmp.height
        val half = maxOf(8, (h * 0.03f).toInt())
        val y0 = maxOf(0, py - half)
        val y1 = minOf(h - 1, py + half)
        val bandH = y1 - y0 + 1
        val pix = IntArray(w * bandH)
        bmp.getPixels(pix, 0, w, 0, y0, w, bandH)

        return analyze(pix, w, h, bandH, y0, px, py)
    }

    /** Parte pura (sin Android) para poder probarla fácilmente. */
    fun analyze(pix: IntArray, w: Int, h: Int, bandH: Int, y0: Int, px: Int, py: Int): IntArray? {
        // 1) Columnas "claras": al menos 30% de la franja tiene color pastel claro
        val need = maxOf(1, (bandH * 0.30f).toInt())
        val colOk = BooleanArray(w)
        for (x in 0 until w) {
            var cnt = 0
            for (row in 0 until bandH) {
                if (isBright(pix[row * w + x])) cnt++
            }
            colOk[x] = cnt >= need
        }

        // 2) Bloques continuos de columnas claras (se puentean huecos chicos por el texto)
        val maxGap = maxOf(2, (w * 0.03f).toInt())
        val runs = ArrayList<IntArray>()
        var start = -1
        var last = -1
        for (x in 0 until w) {
            if (colOk[x]) {
                if (start < 0) start = x
                last = x
            } else if (start >= 0 && x - last > maxGap) {
                runs.add(intArrayOf(start, last))
                start = -1
            }
        }
        if (start >= 0) runs.add(intArrayOf(start, last))

        // 3) Par de bloques vecinos con el puntero entre ambos (con algo de tolerancia)
        val tol = (w * 0.10f).toInt()
        var bestA: IntArray? = null
        var bestB: IntArray? = null
        var bestDist = Int.MAX_VALUE
        for (i in 0 until runs.size - 1) {
            val a = runs[i]
            val b = runs[i + 1]
            if (a[1] >= px + tol || b[0] <= px - tol) continue
            val wa = a[1] - a[0] + 1
            val wb = b[1] - b[0] + 1
            if (wa < w * 0.12f || wb < w * 0.12f) continue
            val ratio = wa.toFloat() / wb.toFloat()
            if (ratio < 0.6f || ratio > 1.67f) continue
            val gap = b[0] - a[1] - 1
            if (gap < w * 0.015f || gap > w * 0.30f) continue
            val dist = Math.abs((a[1] + b[0]) / 2 - px)
            if (dist < bestDist) {
                bestDist = dist
                bestA = a
                bestB = b
            }
        }
        val a = bestA ?: return null
        val b = bestB ?: return null

        // 4) Cuál es OK: el botón con menos texto oscuro en el centro vertical
        val tHalf = maxOf(4, (h * 0.012f).toInt())
        val ty0 = maxOf(y0, py - tHalf)
        val ty1 = minOf(y0 + bandH - 1, py + tHalf)
        val da = darkCount(pix, w, y0, ty0, ty1, a)
        val db = darkCount(pix, w, y0, ty0, ty1, b)

        val ok: IntArray = when {
            db > da * 1.35f && db - da >= 10 -> a
            da > db * 1.35f && da - db >= 10 -> b
            else -> return null
        }
        return intArrayOf((ok[0] + ok[1]) / 2, py)
    }

    private fun darkCount(pix: IntArray, w: Int, y0: Int, ty0: Int, ty1: Int, run: IntArray): Int {
        val margin = ((run[1] - run[0]) * 0.08f).toInt()
        var n = 0
        for (y in ty0..ty1) {
            val rowBase = (y - y0) * w
            for (x in (run[0] + margin)..(run[1] - margin)) {
                if (isDark(pix[rowBase + x])) n++
            }
        }
        return n
    }
}
