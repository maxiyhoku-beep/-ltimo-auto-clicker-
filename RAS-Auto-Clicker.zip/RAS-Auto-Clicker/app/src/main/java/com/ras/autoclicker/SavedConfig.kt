package com.ras.autoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Configuración guardada: posición y velocidad de los punteros + puntero de bonus. */
object SavedConfig {

    class Item(val x: Int, val y: Int, val ms: Long)

    class Data(
        val pointers: List<Item>,
        val bonusEnabled: Boolean,
        val bonusX: Int,
        val bonusY: Int
    )

    private const val PREFS = "ras_prefs"
    private const val KEY = "saved_config"

    fun save(ctx: Context, data: Data) {
        val arr = JSONArray()
        for (p in data.pointers) {
            arr.put(JSONObject().put("x", p.x).put("y", p.y).put("ms", p.ms))
        }
        val obj = JSONObject()
            .put("pointers", arr)
            .put("bonusEnabled", data.bonusEnabled)
            .put("bonusX", data.bonusX)
            .put("bonusY", data.bonusY)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, obj.toString()).apply()
    }

    fun load(ctx: Context): Data? {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return null
        return try {
            val obj = JSONObject(raw)
            val arr = obj.getJSONArray("pointers")
            val list = ArrayList<Item>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Item(o.getInt("x"), o.getInt("y"), o.getLong("ms")))
            }
            Data(list, obj.getBoolean("bonusEnabled"), obj.getInt("bonusX"), obj.getInt("bonusY"))
        } catch (t: Throwable) {
            null
        }
    }

    fun exists(ctx: Context): Boolean = load(ctx) != null
}
