package com.ras.autoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Configuraciones guardadas (varias, cada una con nombre): punteros + puntero de bonus. */
object SavedConfig {

    class Item(val x: Int, val y: Int, val ms: Long)

    class Data(
        val pointers: List<Item>,
        val bonusEnabled: Boolean,
        val bonusX: Int,
        val bonusY: Int
    )

    private const val PREFS = "ras_prefs"
    private const val KEY = "saved_configs"
    private const val OLD_KEY = "saved_config" // versión anterior (una sola configuración)

    private fun readAll(ctx: Context): JSONArray {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        try {
            val raw = prefs.getString(KEY, null)
            if (raw != null) return JSONArray(raw)
            val old = prefs.getString(OLD_KEY, null)
            if (old != null) {
                val obj = JSONObject(old)
                obj.put("name", "Config 1")
                val arr = JSONArray().put(obj)
                prefs.edit().putString(KEY, arr.toString()).remove(OLD_KEY).apply()
                return arr
            }
        } catch (t: Throwable) {
            // datos dañados: se empieza de cero
        }
        return JSONArray()
    }

    private fun writeAll(ctx: Context, arr: JSONArray) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun names(ctx: Context): List<String> {
        val arr = readAll(ctx)
        val list = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val n = arr.optJSONObject(i)?.optString("name", "") ?: ""
            if (n.isNotEmpty()) list.add(n)
        }
        return list
    }

    fun exists(ctx: Context): Boolean = names(ctx).isNotEmpty()

    fun nameExists(ctx: Context, name: String): Boolean = names(ctx).any { it.equals(name, true) }

    /** Guarda con ese nombre; si ya existe uno igual lo reemplaza. */
    fun save(ctx: Context, name: String, data: Data) {
        val items = JSONArray()
        for (p in data.pointers) {
            items.put(JSONObject().put("x", p.x).put("y", p.y).put("ms", p.ms))
        }
        val obj = JSONObject()
            .put("name", name)
            .put("pointers", items)
            .put("bonusEnabled", data.bonusEnabled)
            .put("bonusX", data.bonusX)
            .put("bonusY", data.bonusY)

        val old = readAll(ctx)
        val out = JSONArray()
        var replaced = false
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("name", "").equals(name, true)) {
                out.put(obj)
                replaced = true
            } else {
                out.put(o)
            }
        }
        if (!replaced) out.put(obj)
        writeAll(ctx, out)
    }

    fun load(ctx: Context, name: String): Data? {
        val arr = readAll(ctx)
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            if (!obj.optString("name", "").equals(name, true)) continue
            return try {
                val ptrs = obj.getJSONArray("pointers")
                val list = ArrayList<Item>()
                for (j in 0 until ptrs.length()) {
                    val o = ptrs.getJSONObject(j)
                    list.add(Item(o.getInt("x"), o.getInt("y"), o.getLong("ms")))
                }
                Data(list, obj.getBoolean("bonusEnabled"), obj.getInt("bonusX"), obj.getInt("bonusY"))
            } catch (t: Throwable) {
                null
            }
        }
        return null
    }

    fun delete(ctx: Context, name: String) {
        val old = readAll(ctx)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (!o.optString("name", "").equals(name, true)) out.put(o)
        }
        writeAll(ctx, out)
    }
}
