package com.ras.autoclicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Bandera dibujada a mano: kind = "us" (Estados Unidos) o "ar" (Argentina). */
class FlagView(ctx: Context, private val kind: String) : View(ctx) {

    var chosen: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()

    override fun onDraw(canvas: Canvas) {
        val inset = Ui.dp(context, 3).toFloat()
        val rect = RectF(inset, inset, width - inset, height - inset)
        val radius = Ui.dp(context, 8).toFloat()

        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        if (kind == "us") drawUs(canvas, rect) else drawAr(canvas, rect)
        if (!chosen) {
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(130, 0, 0, 0)
            canvas.drawRect(rect, paint)
        }
        canvas.restore()

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = Ui.dp(context, if (chosen) 3 else 1).toFloat()
        paint.color = if (chosen) Ui.GOLD else Ui.GRAY
        canvas.drawRoundRect(rect, radius, radius, paint)
    }

    private fun drawUs(c: Canvas, r: RectF) {
        val stripe = r.height() / 13f
        paint.style = Paint.Style.FILL
        for (i in 0 until 13) {
            paint.color = if (i % 2 == 0) Color.parseColor("#B22234") else Color.WHITE
            c.drawRect(r.left, r.top + i * stripe, r.right, r.top + (i + 1) * stripe, paint)
        }
        val cantonW = r.width() * 0.42f
        val cantonH = stripe * 7f
        paint.color = Color.parseColor("#3C3B6E")
        c.drawRect(r.left, r.top, r.left + cantonW, r.top + cantonH, paint)
        paint.color = Color.WHITE
        val cols = 5
        val rows = 4
        for (row in 0 until rows) {
            for (col in 0 until cols) {
                val cx = r.left + cantonW * (col + 0.7f) / (cols + 0.4f)
                val cy = r.top + cantonH * (row + 0.7f) / (rows + 0.4f)
                c.drawCircle(cx, cy, stripe * 0.28f, paint)
            }
        }
    }

    private fun drawAr(c: Canvas, r: RectF) {
        val third = r.height() / 3f
        paint.style = Paint.Style.FILL
        val blue = Color.parseColor("#74ACDF")
        paint.color = blue
        c.drawRect(r.left, r.top, r.right, r.top + third, paint)
        paint.color = Color.WHITE
        c.drawRect(r.left, r.top + third, r.right, r.top + 2 * third, paint)
        paint.color = blue
        c.drawRect(r.left, r.top + 2 * third, r.right, r.bottom, paint)
        paint.color = Color.parseColor("#F6B40E")
        c.drawCircle(r.centerX(), r.centerY(), r.height() * 0.11f, paint)
    }
}
