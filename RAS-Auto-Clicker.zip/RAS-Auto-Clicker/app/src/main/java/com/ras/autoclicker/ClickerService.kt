package com.ras.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.TargetApi
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.LinkedList
import java.util.concurrent.Executors

/**
 * Servicio de accesibilidad: hace los toques en pantalla (gestos) y saca capturas
 * para detectar el bonus. También es el "dueño" del panel y los punteros flotantes.
 */
class ClickerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickerService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val background = Executors.newSingleThreadExecutor()
    private val queue = LinkedList<FloatArray>()
    private var dispatching = false
    private var controller: OverlayController? = null

    /**
     * Mientras el usuario toca el panel no se mandan toques automáticos, así los botones
     * (sobre todo Pausa) siempre responden.
     */
    @Volatile
    var holdTaps: Boolean = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No hace falta reaccionar a eventos.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        controller?.destroy()
        controller = null
        queue.clear()
        dispatching = false
        holdTaps = false
        instance = null
    }

    // ---------------------------------------------------------------- Panel

    fun isPanelShown(): Boolean = controller != null

    fun showPanel(useSaved: Boolean = false) {
        if (controller != null) return
        val c = OverlayController(this)
        controller = c
        c.show(useSaved)
    }

    fun hidePanel() {
        controller?.destroy()
        controller = null
        queue.clear()
        holdTaps = false
    }

    // ---------------------------------------------------------------- Toques

    /** Agrega un toque a la cola; se ejecutan de a uno para que no se pisen. */
    fun enqueueTap(x: Float, y: Float) {
        if (holdTaps) return
        if (queue.size >= 30) return
        queue.add(floatArrayOf(x, y))
        pump()
    }

    /** Descarta los toques pendientes (se usa al pausar). */
    fun clearQueue() {
        queue.clear()
    }

    private fun pump() {
        if (dispatching) return
        if (holdTaps) {
            queue.clear()
            return
        }
        val tap = queue.poll() ?: return
        dispatching = true

        val path = Path()
        path.moveTo(tap[0], tap[1])
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                finishTap()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                finishTap()
            }
        }, null)

        if (!accepted) finishTap()
    }

    private fun finishTap() {
        main.post {
            dispatching = false
            pump()
        }
    }

    // ---------------------------------------------------------------- Bonus

    /**
     * Saca una captura y busca el cartel de bonus alrededor del puntero (px, py).
     * Llama a [callback] en el hilo principal con [x, y] donde tocar, o null.
     */
    @TargetApi(Build.VERSION_CODES.R)
    fun detectBonus(px: Int, py: Int, callback: (IntArray?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            callback(null)
            return
        }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, background, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    var result: IntArray? = null
                    try {
                        val buffer = screenshot.hardwareBuffer
                        val hardware = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                        if (hardware != null) {
                            val soft = hardware.copy(Bitmap.Config.ARGB_8888, false)
                            hardware.recycle()
                            if (soft != null) {
                                result = BonusDetector.find(soft, px, py)
                                soft.recycle()
                            }
                        }
                        buffer.close()
                    } catch (t: Throwable) {
                        result = null
                    }
                    main.post { callback(result) }
                }

                override fun onFailure(errorCode: Int) {
                    main.post { callback(null) }
                }
            })
        } catch (t: Throwable) {
            callback(null)
        }
    }
}
