package com.ras.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var screen = "home"
    private lateinit var root: FrameLayout

    private val channels = listOf(
        Pair("FELCOR", "https://youtube.com/@felcor?si=h24n3RTS_8o2Ljlu"),
        Pair("comer305", "https://youtube.com/@comer305?si=XJDEP0JpTCxKhfww"),
        Pair("DYLANFUT", "https://youtube.com/@dylanfut2322?si=ujxpJ9Wj_I8IDr5c"),
        Pair("FRYKKO", "https://youtube.com/@frykko57?si=QygSlJB8722jEyET")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.load(this)
        window.statusBarColor = Ui.BLACK
        window.navigationBarColor = Ui.BLACK
        root = FrameLayout(this)
        root.setBackgroundColor(Ui.BLACK)
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen != "home") {
            screen = "home"
            render()
        } else {
            super.onBackPressed()
        }
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun rowParams(top: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(top)
        return lp
    }

    private fun render() {
        root.removeAllViews()

        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg_main)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(
            bg,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val topPad = (resources.displayMetrics.heightPixels * 0.36f).toInt()
        col.setPadding(dp(26), topPad, dp(26), dp(28))
        scroll.addView(
            col,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        root.addView(
            scroll,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        if (screen == "channels") buildChannels(col) else buildHome(col)
    }

    // ------------------------------------------------------------ Pantalla principal

    private fun buildHome(col: LinearLayout) {
        val service = ClickerService.instance
        val active = service != null
        val panelOn = service?.isPanelShown() == true

        val status = Ui.label(
            this,
            L.t(if (active) "status_on" else "status_off"),
            13f,
            if (active) Ui.GREEN else Ui.RED,
            true
        )
        status.gravity = Gravity.CENTER
        col.addView(status, rowParams(0))

        val panelBtn = Ui.button(this, L.t(if (panelOn) "disable_panel" else "enable_panel"), true)
        panelBtn.textSize = 19f
        panelBtn.setOnClickListener { onTogglePanel() }
        col.addView(panelBtn, rowParams(18))

        val channelsBtn = Ui.button(this, L.t("channels"), false)
        channelsBtn.setOnClickListener {
            screen = "channels"
            render()
        }
        col.addView(channelsBtn, rowParams(14))

        val langLabel = Ui.label(this, L.t("language"), 13f, Ui.GOLD, true)
        langLabel.gravity = Gravity.CENTER
        col.addView(langLabel, rowParams(26))

        val flags = LinearLayout(this)
        flags.orientation = LinearLayout.HORIZONTAL
        flags.gravity = Gravity.CENTER
        val us = FlagView(this, "us")
        val ar = FlagView(this, "ar")
        us.chosen = L.lang == "en"
        ar.chosen = L.lang == "es"
        us.setOnClickListener {
            L.set(this, "en")
            render()
        }
        ar.setOnClickListener {
            L.set(this, "es")
            render()
        }
        val flagParams = LinearLayout.LayoutParams(dp(76), dp(54))
        flagParams.leftMargin = dp(8)
        flagParams.rightMargin = dp(8)
        flags.addView(us, flagParams)
        flags.addView(ar, LinearLayout.LayoutParams(flagParams))
        col.addView(flags, rowParams(6))

        val hint = Ui.label(this, L.t("hint_main"), 12.5f, Ui.GRAY, false)
        hint.gravity = Gravity.CENTER
        col.addView(hint, rowParams(22))
    }

    private fun onTogglePanel() {
        val service = ClickerService.instance
        if (service == null) {
            showAccessibilityDialog()
            return
        }
        if (service.isPanelShown()) {
            service.hidePanel()
            Toast.makeText(this, L.t("panel_off"), Toast.LENGTH_SHORT).show()
            render()
        } else {
            service.showPanel()
            Toast.makeText(this, L.t("panel_on"), Toast.LENGTH_LONG).show()
            render()
            moveTaskToBack(true)
        }
    }

    private fun showAccessibilityDialog() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(L.t("acc_title"))
            .setMessage(L.t("acc_msg"))
            .setPositiveButton(L.t("open_settings")) { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (t: Throwable) {
                    Toast.makeText(this, L.t("open_failed"), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(L.t("cancel"), null)
            .show()
    }

    // ------------------------------------------------------------ Canales

    private fun buildChannels(col: LinearLayout) {
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        col.addView(logo, LinearLayout.LayoutParams(dp(110), dp(110)))

        val title = Ui.label(this, L.t("channels_title"), 22f, Ui.GOLD, true)
        title.gravity = Gravity.CENTER
        col.addView(title, rowParams(12))

        for (channel in channels) {
            val b = Ui.button(this, "${L.t("channel_prefix")} ${channel.first}", false)
            b.setOnClickListener { openLink(channel.second) }
            col.addView(b, rowParams(12))
        }

        val back = Ui.button(this, L.t("back"), true)
        back.setOnClickListener {
            screen = "home"
            render()
        }
        col.addView(back, rowParams(22))
    }

    private fun openLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (t: Throwable) {
            Toast.makeText(this, L.t("open_failed"), Toast.LENGTH_SHORT).show()
        }
    }
}
