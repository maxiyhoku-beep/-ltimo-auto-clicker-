package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.TextView

/** Colores y ayudas de diseño (negro + dorado). */
object Ui {
    val GOLD: Int = Color.parseColor("#FFC83D")
    val GOLD_LIGHT: Int = Color.parseColor("#FFE58A")
    val GOLD_DARK: Int = Color.parseColor("#C98A00")
    val BLACK: Int = Color.parseColor("#0A0A0A")
    val PANEL: Int = Color.parseColor("#141414")
    val GRAY: Int = Color.parseColor("#8A8A8A")
    val RED: Int = Color.parseColor("#E53935")
    val GREEN: Int = Color.parseColor("#2ECC71")

    // Colores de los botones del panel (cada uno se distingue)
    val BTN_PLAY: Int = Color.parseColor("#22C55E")
    val BTN_PAUSE: Int = Color.parseColor("#FF5A36")
    val BTN_ADD: Int = Color.parseColor("#1E88E5")
    val BTN_REMOVE: Int = Color.parseColor("#FF9800")
    val BTN_EYE: Int = Color.parseColor("#A855F7")
    val BTN_STAR: Int = Color.parseColor("#FFC83D")
    val BTN_CLOSE: Int = Color.parseColor("#E53935")
    val BTN_SAVE: Int = Color.parseColor("#14B8A6")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    /** Fondo oscuro con borde dorado. */
    fun darkBg(ctx: Context, radiusDp: Int, strokeDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(PANEL)
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        d.setStroke(dp(ctx, strokeDp), GOLD)
        return d
    }

    /** Fondo dorado degradado. */
    fun goldBg(ctx: Context, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(GOLD_LIGHT, GOLD, GOLD_DARK)
        )
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        d.setStroke(dp(ctx, 1), BLACK)
        return d
    }

    /** Círculo de color con borde dorado (botones del panel). */
    fun circle(ctx: Context, color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        d.setStroke(dp(ctx, 2), GOLD)
        return d
    }

    fun label(ctx: Context, text: String, sizeSp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        return t
    }

    /** Efecto al tocar: el botón se achica un poquito. */
    @SuppressLint("ClickableViewAccessibility")
    fun feedback(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(60).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
            }
            false
        }
    }

    /** Botón de texto: dorado (acción principal) u oscuro con borde dorado. */
    fun button(ctx: Context, text: String, gold: Boolean): TextView {
        val t = label(ctx, text, 16f, if (gold) BLACK else GOLD, true)
        t.gravity = Gravity.CENTER
        t.letterSpacing = 0.06f
        t.setPadding(dp(ctx, 16), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14))
        t.background = if (gold) goldBg(ctx, 14) else darkBg(ctx, 14, 2)
        feedback(t)
        return t
    }

    /** Botón chico para ventanas compactas. */
    fun smallButton(ctx: Context, text: String, gold: Boolean): TextView {
        val t = label(ctx, text, 14f, if (gold) BLACK else GOLD, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(ctx, 8), dp(ctx, 8), dp(ctx, 8), dp(ctx, 8))
        t.background = if (gold) goldBg(ctx, 10) else darkBg(ctx, 10, 2)
        feedback(t)
        return t
    }
}
