package com.ras.autoclicker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

/** Colores y ayudas de diseño (negro + dorado). */
object Ui {
    val GOLD: Int = Color.parseColor("#FFC83D")
    val GOLD_LIGHT: Int = Color.parseColor("#FFE58A")
    val GOLD_DARK: Int = Color.parseColor("#C98A00")
    val BLACK: Int = Color.parseColor("#0A0A0A")
    val PANEL: Int = Color.parseColor("#141414")
    val GRAY: Int = Color.parseColor("#8A8A8A")
    val RED: Int = Color.parseColor("#E53935")
    val GREEN: Int = Color.parseColor("#2ECC71")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    /** Fondo oscuro con borde dorado. */
    fun darkBg(ctx: Context, radiusDp: Int, strokeDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(PANEL)
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        d.setStroke(dp(ctx, strokeDp), GOLD)
        return d
    }

    /** Fondo dorado degradado. */
    fun goldBg(ctx: Context, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(GOLD_LIGHT, GOLD, GOLD_DARK)
        )
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        d.setStroke(dp(ctx, 1), BLACK)
        return d
    }

    fun label(ctx: Context, text: String, sizeSp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        return t
    }

    /** Botón de texto: dorado (acción principal) u oscuro con borde dorado. */
    fun button(ctx: Context, text: String, gold: Boolean): TextView {
        val t = label(ctx, text, 16f, if (gold) BLACK else GOLD, true)
        t.gravity = Gravity.CENTER
        t.letterSpacing = 0.06f
        t.setPadding(dp(ctx, 16), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14))
        t.background = if (gold) goldBg(ctx, 14) else darkBg(ctx, 14, 2)
        return t
    }
}
