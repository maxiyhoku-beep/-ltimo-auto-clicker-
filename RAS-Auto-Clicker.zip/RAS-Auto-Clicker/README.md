# RAS//Auto-Clicker

Auto clicker para el juego de celular **SMOQ**: punteros con velocidad editable, panel flotante,
puntero dorado que detecta el cartel de **BONUS** y toca **OK**, idiomas Español/Inglés y sección de Canales.

## Cómo compilarlo con GitHub (sin descomprimir nada)

1. Creá un repositorio nuevo en https://github.com.
2. **Add file → Upload files** y subí este ZIP tal cual (sin descomprimir). Tocá **Commit changes**.
3. **Add file → Create new file**. Como nombre escribí exactamente `.github/workflows/build.yml`
   (al escribir las barras `/` se crean las carpetas). Pegá el código del archivo `build.yml`
   que te pasó Claude y tocá **Commit changes**.
4. Entrá a la pestaña **Actions**. La compilación arranca sola, descomprime el ZIP y genera el APK
   (tarda 3–6 minutos). Si no arranca, entrá a la ejecución → **Run workflow**.
5. Cuando termine con el tilde verde, abrí esa ejecución y, abajo en **Artifacts**, descargá
   **RAS-Auto-Clicker-APK**. Adentro está el `.apk`.
6. Pasá el `.apk` al celular e instalalo.

Si la compilación falla, abrí la ejecución, copiá el error y pasáselo a Claude.

## Primer uso en el celular

1. Abrí **RAS//Auto-Clicker** y tocá **ACTIVAR PANEL**.
2. La primera vez te lleva a Accesibilidad: activá el servicio **RAS//Auto-Clicker**.
   - Si Android lo bloquea ("ajuste restringido"): Ajustes → Apps → RAS//Auto-Clicker → menú ⋮ →
     **Permitir ajustes restringidos**, y probá otra vez.
3. Volvé a la app y tocá **ACTIVAR PANEL**. Abrí el juego.

## Panel flotante

| Botón | Qué hace |
|---|---|
| ☰ | Mover el panel (arrastrar) |
| ▶ / ■ | Iniciar / pausar los clics |
| + / − | Agregar / quitar punteros |
| ◉ / ○ | Ocultar / mostrar punteros (ocultos siguen funcionando) |
| ★ | Activar / desactivar el puntero dorado de bonus |
| ✕ | Cerrar el panel |

- **Punteros normales**: rojos en pausa, verdes funcionando. Arrastralos en pausa para ubicarlos.
- **Cambiar la velocidad**: en pausa, tocá un puntero y elegí el valor en **ms** o **s**.
- **Puntero dorado (★)**: ponelo en el medio de los dos botones del cartel BONUS (entre OK y GO TO CARDS).
  Con el auto clicker iniciado, cuando aparece el cartel toca solo **OK**, esté a la izquierda o a la derecha.
  Necesita Android 11 o superior.

## Idiomas

En la pantalla principal tocá la bandera de Estados Unidos (inglés) o la de Argentina (español).
